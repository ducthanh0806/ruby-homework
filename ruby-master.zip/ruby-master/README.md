# ruby
bài tập về nhà
